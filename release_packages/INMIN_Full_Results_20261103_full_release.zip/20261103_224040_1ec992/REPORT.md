# INMIN full-system DSE

Complete schema3 analytical oracle; fixed reference and original Tangram-style seed. All methods use the same design domain.

|Method|Full PPA|Cost gain %|Latency gain %|Energy gain %|Area gain %|Architecture|Fusion depth|SGD|Charged s|
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
|rl|8|97.85829652108185|87.23840961044594|83.2175817155891|0.0|single_array_c1_1x1|0|144|7.326933399774134|

RL: multi-step action-conditioned Double Q with target network and physical improvement reward. Random/SA are controls on this same oracle, not original Gemini/Tangram binaries.
SGD, proposal proxies, cache hits and timeouts are not full PPA. Capacity-invalid completed schedules count as full PPA. No global optimum or silicon accuracy is claimed.
