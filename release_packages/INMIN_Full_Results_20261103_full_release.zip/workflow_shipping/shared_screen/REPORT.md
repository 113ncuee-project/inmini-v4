# INMIN full-system DSE

Complete schema3 analytical oracle; fixed reference and original Tangram-style seed. All methods use the same design domain.

|Method|Full PPA|Cost gain %|Latency gain %|Energy gain %|Area gain %|Architecture|Fusion depth|SGD|Charged s|
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
|rl|58|94.94403180526358|79.16415705158113|75.73427575139169|0.0|single_array_c1_1x1|0|224|39.107718999963254|
|sa|58|94.94403180526358|79.16415705158113|75.73427575139169|0.0|single_array_c1_1x1|0|0|33.15651770005934|
|random|58|94.94403180526358|79.16415705158113|75.73427575139169|0.0|single_array_c1_1x1|0|0|33.11081130011007|

RL: multi-step action-conditioned Double Q with target network and physical improvement reward. Random/SA are controls on this same oracle, not original Gemini/Tangram binaries.
SGD, proposal proxies, cache hits and timeouts are not full PPA. Capacity-invalid completed schedules count as full PPA. No global optimum or silicon accuracy is claimed.
