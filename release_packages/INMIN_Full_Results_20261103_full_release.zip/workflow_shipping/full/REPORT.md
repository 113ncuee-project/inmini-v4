# INMIN full-system DSE

Complete schema3 analytical oracle; fixed reference and original Tangram-style seed. All methods use the same design domain.

|Method|Full PPA|Cost gain %|Latency gain %|Energy gain %|Area gain %|Architecture|Fusion depth|SGD|Charged s|
|---|---:|---:|---:|---:|---:|---|---:|---:|---:|
|rl|14|97.85829652108185|87.23840961044594|83.2175817155891|0.0|single_array_c1_1x1|0|96|10.838799400022253|
|sa|14|62.527441266767525|39.572417096822896|37.98765905749595|0.0|single_array_c1_1x1|0|0|4.662271700100973|
|random|14|62.527441266767525|39.572417096822896|37.98765905749595|0.0|single_array_c1_1x1|0|0|4.738281200174242|

RL: multi-step action-conditioned Double Q with target network and physical improvement reward. Random/SA are controls on this same oracle, not original Gemini/Tangram binaries.
SGD, proposal proxies, cache hits and timeouts are not full PPA. Capacity-invalid completed schedules count as full PPA. No global optimum or silicon accuracy is claimed.
